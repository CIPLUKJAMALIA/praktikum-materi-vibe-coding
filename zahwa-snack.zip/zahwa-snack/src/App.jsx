import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  FolderTree, 
  ShoppingCart, 
  Users, 
  FileText, 
  History, 
  Store, 
  Bell, 
  Search, 
  Plus, 
  Trash2, 
  Edit, 
  Printer, 
  Download, 
  TrendingUp, 
  AlertTriangle, 
  DollarSign, 
  CheckCircle, 
  X, 
  Filter, 
  LogOut, 
  Menu, 
  ChevronRight,
  ArrowUpDown,
  RefreshCw,
  Minus,
  Eye,
  User,
  ShoppingBag,
  Award,
  Sparkles
} from 'lucide-react';

const INITIAL_CATEGORIES = [
  { id: 'cat-1', name: 'Keripik & Kripik', description: 'Aneka keripik renyah guri h dan pedas' },
  { id: 'cat-2', name: 'Kue Kering', description: 'Kue kering tradisional dan modern' },
  { id: 'cat-3', name: 'Kacang-kacangan', description: 'Kacang olahan oven dan goreng' },
  { id: 'cat-4', name: 'Permen & Manisan', description: 'Manisan buah dan permen jadul' }
];

const INITIAL_PRODUCTS = [
  { 
    id: 'prd-1', 
    code: 'ZS-001', 
    name: 'Keripik Singkong Balado', 
    categoryId: 'cat-1', 
    price: 15000, 
    costPrice: 10000, 
    stock: 45, 
    minStock: 10, 
    unit: 'Bungkus', 
    image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=400&auto=format&fit=crop&q=80',
    salesCount: 120
  },
  { 
    id: 'prd-2', 
    code: 'ZS-002', 
    name: 'Keripik Pisang Cokelat Lumer', 
    categoryId: 'cat-1', 
    price: 18000, 
    costPrice: 12000, 
    stock: 8, 
    minStock: 15, 
    unit: 'Pouch', 
    image: 'https://images.unsplash.com/photo-1621939514649-280e2ee25f60?w=400&auto=format&fit=crop&q=80',
    salesCount: 95
  },
  { 
    id: 'prd-3', 
    code: 'ZS-003', 
    name: 'Makaroni Pedas Daun Jeruk', 
    categoryId: 'cat-1', 
    price: 12000, 
    costPrice: 7500, 
    stock: 60, 
    minStock: 10, 
    unit: 'Bungkus', 
    image: 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?w=400&auto=format&fit=crop&q=80',
    salesCount: 210
  },
  { 
    id: 'prd-4', 
    code: 'ZS-004', 
    name: 'Kacang Bawang Renyah 250g', 
    categoryId: 'cat-3', 
    price: 25000, 
    costPrice: 18000, 
    stock: 5, 
    minStock: 10, 
    unit: 'Toples', 
    image: 'https://images.unsplash.com/photo-1536591375315-1b83681e5e34?w=400&auto=format&fit=crop&q=80',
    salesCount: 40
  },
  { 
    id: 'prd-5', 
    code: 'ZS-005', 
    name: 'Nastar Keju Wisman', 
    categoryId: 'cat-2', 
    price: 65000, 
    costPrice: 45000, 
    stock: 12, 
    minStock: 5, 
    unit: 'Toples', 
    image: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&auto=format&fit=crop&q=80',
    salesCount: 75
  },
  { 
    id: 'prd-6', 
    code: 'ZS-006', 
    name: 'Kastengel Keju Edam', 
    categoryId: 'cat-2', 
    price: 70000, 
    costPrice: 50000, 
    stock: 3, 
    minStock: 8, 
    unit: 'Toples', 
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&auto=format&fit=crop&q=80',
    salesCount: 60
  }
];

const INITIAL_CUSTOMERS = [
  { id: 'cust-1', name: 'Budi Santoso', phone: '081234567890', address: 'Jl. Merdeka No. 12, Jakarta', totalOrders: 15, totalSpent: 450000 },
  { id: 'cust-2', name: 'Siti Aminah', phone: '082198765432', address: 'Jl. Mawar No. 45, Bandung', totalOrders: 8, totalSpent: 280000 },
  { id: 'cust-3', name: 'Pelanggan Umum (Walk-in)', phone: '-', address: '-', totalOrders: 42, totalSpent: 1250000 }
];

const INITIAL_TRANSACTIONS = [
  {
    id: 'TRX-20261019-001',
    date: '2026-10-19T10:30:00',
    customerId: 'cust-1',
    customerName: 'Budi Santoso',
    items: [
      { id: 'prd-1', name: 'Keripik Singkong Balado', price: 15000, quantity: 2, subtotal: 30000 },
      { id: 'prd-3', name: 'Makaroni Pedas Daun Jeruk', price: 12000, quantity: 1, subtotal: 12000 }
    ],
    subtotal: 42000,
    discount: 2000,
    total: 40000,
    paymentMethod: 'Cash',
    paidAmount: 50000,
    changeAmount: 10000,
    cashier: 'Admin Zahwa'
  },
  {
    id: 'TRX-20261020-002',
    date: '2026-10-20T08:15:00',
    customerId: 'cust-3',
    customerName: 'Pelanggan Umum (Walk-in)',
    items: [
      { id: 'prd-5', name: 'Nastar Keju Wisman', price: 65000, quantity: 1, subtotal: 65000 },
      { id: 'prd-2', name: 'Keripik Pisang Cokelat Lumer', price: 18000, quantity: 2, subtotal: 36000 }
    ],
    subtotal: 101000,
    discount: 0,
    total: 101000,
    paymentMethod: 'QRIS',
    paidAmount: 101000,
    changeAmount: 0,
    cashier: 'Admin Zahwa'
  }
];

const INITIAL_STOCK_LOGS = [
  { id: 'log-1', date: '2026-10-19T10:30:00', productName: 'Keripik Singkong Balado', type: 'OUT', qty: 2, note: 'Penjualan TRX-20261019-001' },
  { id: 'log-2', date: '2026-10-19T10:30:00', productName: 'Makaroni Pedas Daun Jeruk', type: 'OUT', qty: 1, note: 'Penjualan TRX-20261019-001' },
  { id: 'log-3', date: '2026-10-20T08:15:00', productName: 'Nastar Keju Wisman', type: 'OUT', qty: 1, note: 'Penjualan TRX-20261020-002' },
  { id: 'log-4', date: '2026-10-20T08:15:00', productName: 'Keripik Pisang Cokelat Lumer', type: 'OUT', qty: 2, note: 'Penjualan TRX-20261020-002' }
];

const INITIAL_PROFILE = {
  name: 'Zahwa Snack & Bakery',
  tagline: 'Camilan Lezat & Berkualitas Setiap Hari',
  owner: 'Ibu Zahwa Nurhaliza',
  phone: '0812-3456-7890',
  email: 'info@zahwasnack.com',
  address: 'Jl. Raya Sunan Kudus No. 88, Jawa Tengah',
  description: 'Usaha Mikro Kecil Menengah yang bergerak di bidang produksi dan distribusi aneka makanan ringan lezat khas nusantara dan pastry berkualitas tinggi.'
};

export default function App() {
  // Login State
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem('zahwa_logged_in') === 'true';
  });
  const [loginUser, setLoginUser] = useState({ username: 'admin', role: 'Pemilik Usaha' });

  // Navigation State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // LocalStorage Persisted Data
  const [categories, setCategories] = useState(() => {
    const saved = localStorage.getItem('zahwa_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('zahwa_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [customers, setCustomers] = useState(() => {
    const saved = localStorage.getItem('zahwa_customers');
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('zahwa_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [stockLogs, setStockLogs] = useState(() => {
    const saved = localStorage.getItem('zahwa_stock_logs');
    return saved ? JSON.parse(saved) : INITIAL_STOCK_LOGS;
  });

  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem('zahwa_profile');
    return saved ? JSON.parse(saved) : INITIAL_PROFILE;
  });

  // UI & Form Modals State
  const [toast, setToast] = useState(null);
  const [confirmModal, setConfirmModal] = useState({ isOpen: false, title: '', message: '', onConfirm: null });

  // Sync state changes to LocalStorage
  useEffect(() => { localStorage.setItem('zahwa_logged_in', isLoggedIn); }, [isLoggedIn]);
  useEffect(() => { localStorage.setItem('zahwa_categories', JSON.stringify(categories)); }, [categories]);
  useEffect(() => { localStorage.setItem('zahwa_products', JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem('zahwa_customers', JSON.stringify(customers)); }, [customers]);
  useEffect(() => { localStorage.setItem('zahwa_transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('zahwa_stock_logs', JSON.stringify(stockLogs)); }, [stockLogs]);
  useEffect(() => { localStorage.setItem('zahwa_profile', JSON.stringify(profile)); }, [profile]);

  // Helper function to show notifications
  const showNotification = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const lowStockProducts = useMemo(() => {
    return products.filter(p => p.stock <= p.minStock);
  }, [products]);

  // Handle Login / Logout
  const handleLogin = (e) => {
    e.preventDefault();
    setIsLoggedIn(true);
    showNotification('Selamat datang kembali di Zahwa Snack Management!');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    showNotification('Berhasil keluar dari sistem', 'info');
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4 font-sans text-slate-800">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-purple-200">
          <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-8 text-center text-white relative overflow-hidden">
            <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
            <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mx-auto mb-4 border border-white/30 shadow-inner">
              <Store className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Zahwa Snack</h1>
            <p className="text-purple-100 text-xs mt-1">Management System UMKM</p>
          </div>

          <form onSubmit={handleLogin} className="p-8 space-y-5">
            <div className="text-center mb-2">
              <h2 className="text-lg font-semibold text-purple-950">Masuk ke System</h2>
              <p className="text-xs text-slate-500">Silahkan gunakan akun demo di bawah</p>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Username</label>
              <input 
                type="text" 
                defaultValue="admin" 
                required
                className="w-full px-4 py-2.5 text-sm rounded-xl border border-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition" 
                placeholder="Masukkan username"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-semibold text-slate-700">Kata Sandi</label>
              <input 
                type="password" 
                defaultValue="123456" 
                required
                className="w-full px-4 py-2.5 text-sm rounded-xl border border-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition" 
                placeholder="••••••••"
              />
            </div>

            <div className="bg-purple-50 p-3.5 rounded-xl border border-purple-100 text-xs text-purple-800 space-y-1">
              <p className="font-semibold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-600" /> Mode Simulasi Vibe Coding:
              </p>
              <p className="text-slate-600">Klik tombol di bawah untuk langsung mencoba aplikasi secara penuh dengan data dummy bawaan.</p>
            </div>

            <button 
              type="submit" 
              className="w-full py-3 px-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-medium rounded-xl shadow-lg shadow-purple-500/25 transition duration-200 active:scale-[0.98]"
            >
              Masuk Dashboard
            </button>

            <div className="text-center pt-2">
              <span className="text-[11px] text-slate-400">Tugas Kuliah Web &copy; 2026 Zahwa Snack</span>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col md:flex-row font-sans">
      
      {/* Toast Notification Floating */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-3 px-4 py-3 rounded-2xl shadow-xl text-white font-medium text-sm transition-all duration-300 animate-bounce ${
          toast.type === 'error' ? 'bg-red-500' : toast.type === 'info' ? 'bg-blue-600' : 'bg-purple-700'
        }`}>
          {toast.type === 'error' ? <AlertTriangle className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmModal.isOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-purple-100 animate-in fade-in zoom-in duration-150">
            <h3 className="text-lg font-bold text-slate-900 mb-2">{confirmModal.title}</h3>
            <p className="text-sm text-slate-600 mb-6">{confirmModal.message}</p>
            <div className="flex gap-3 justify-end">
              <button 
                onClick={() => setConfirmModal({ ...confirmModal, isOpen: false })}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 transition"
              >
                Batal
              </button>
              <button 
                onClick={() => {
                  confirmModal.onConfirm();
                  setConfirmModal({ ...confirmModal, isOpen: false });
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-700 text-white shadow-md shadow-red-200 transition"
              >
                Lanjutkan Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar Navigation */}
      <aside className={`fixed md:static inset-y-0 left-0 z-40 w-64 bg-slate-900 text-white flex flex-col transition-transform duration-300 ${
        mobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
      }`}>
        {/* Sidebar Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-gradient-to-r from-purple-900/50 to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center shadow-lg shadow-purple-600/30">
              <Store className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-sm tracking-wide text-white">Zahwa Snack</h1>
              <p className="text-[10px] text-purple-300">Management System</p>
            </div>
          </div>
          <button className="md:hidden text-slate-400 hover:text-white" onClick={() => setMobileMenuOpen(false)}>
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'pos', label: 'Kasir / POS', icon: ShoppingCart, badge: 'Utama' },
            { id: 'products', label: 'Kelola Produk', icon: Package },
            { id: 'categories', label: 'Kategori Produk', icon: FolderTree },
            { id: 'stock_logs', label: 'Riwayat Stok', icon: Bell, alert: lowStockProducts.length },
            { id: 'customers', label: 'Data Pelanggan', icon: Users },
            { id: 'transactions', label: 'Riwayat Transaksi', icon: History },
            { id: 'reports', label: 'Laporan Penjualan', icon: FileText },
            { id: 'profile', label: 'Profil Usaha', icon: Store }
          ].map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-medium transition duration-150 ${
                  isActive 
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30 font-semibold' 
                    : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-purple-500/30 text-purple-200 rounded-full border border-purple-400/30">
                    {item.badge}
                  </span>
                )}
                {item.alert > 0 && (
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-amber-500 text-white rounded-full animate-pulse">
                    {item.alert}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer User Info */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-purple-200 text-purple-800 flex items-center justify-center font-bold text-xs">
                AZ
              </div>
              <div>
                <p className="text-xs font-semibold text-slate-200">Admin Zahwa</p>
                <p className="text-[10px] text-slate-400">Pemilik Usaha</p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition"
              title="Keluar"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Viewport */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Top Header Bar */}
        <header className="h-16 bg-white border-b border-purple-100 flex items-center justify-between px-4 md:px-8 sticky top-0 z-30 shadow-sm">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setMobileMenuOpen(true)}
              className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-xl"
            >
              <Menu className="w-5 h-5" />
            </button>
            <h2 className="text-base md:text-lg font-bold text-purple-950 capitalize flex items-center gap-2">
              {activeTab === 'pos' && 'Kasir / Transaksi Penjualan'}
              {activeTab === 'dashboard' && 'Dashboard Overview'}
              {activeTab === 'products' && 'Manajemen Produk Snack'}
              {activeTab === 'categories' && 'Kategori Produk'}
              {activeTab === 'stock_logs' && 'Monitoring & Riwayat Stok'}
              {activeTab === 'customers' && 'Manajemen Pelanggan'}
              {activeTab === 'transactions' && 'Riwayat Transaksi'}
              {activeTab === 'reports' && 'Laporan Penjualan & Keuangan'}
              {activeTab === 'profile' && 'Profil Identitas Usaha'}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Low stock quick notification icon */}
            <div className="relative">
              <button 
                onClick={() => setActiveTab('stock_logs')}
                className="p-2 text-slate-500 hover:text-purple-700 hover:bg-purple-50 rounded-xl transition relative"
                title="Pemberitahuan Stok Menipis"
              >
                <Bell className="w-5 h-5" />
                {lowStockProducts.length > 0 && (
                  <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full ring-2 ring-white"></span>
                )}
              </button>
            </div>

            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs font-semibold text-slate-700">Tanggal Sistem</span>
              <span className="text-[11px] text-purple-600 font-medium">
                {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            </div>
          </div>
        </header>

        {/* Content Body based on Active Navigation Tab */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-purple-50/30">
          {activeTab === 'dashboard' && (
            <DashboardView 
              products={products} 
              transactions={transactions} 
              customers={customers} 
              lowStockProducts={lowStockProducts}
              setActiveTab={setActiveTab}
            />
          )}

          {activeTab === 'pos' && (
            <POSView 
              products={products} 
              setProducts={setProducts}
              customers={customers}
              transactions={transactions}
              setTransactions={setTransactions}
              stockLogs={stockLogs}
              setStockLogs={setStockLogs}
              showNotification={showNotification}
            />
          )}

          {activeTab === 'products' && (
            <ProductsView 
              products={products} 
              setProducts={setProducts} 
              categories={categories}
              showNotification={showNotification}
              setConfirmModal={setConfirmModal}
            />
          )}

          {activeTab === 'categories' && (
            <CategoriesView 
              categories={categories} 
              setCategories={setCategories}
              products={products}
              showNotification={showNotification}
              setConfirmModal={setConfirmModal}
            />
          )}

          {activeTab === 'stock_logs' && (
            <StockLogsView 
              products={products}
              setProducts={setProducts}
              stockLogs={stockLogs}
              setStockLogs={setStockLogs}
              showNotification={showNotification}
            />
          )}

          {activeTab === 'customers' && (
            <CustomersView 
              customers={customers} 
              setCustomers={setCustomers}
              showNotification={showNotification}
              setConfirmModal={setConfirmModal}
            />
          )}

          {activeTab === 'transactions' && (
            <TransactionsView 
              transactions={transactions}
              profile={profile}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView 
              transactions={transactions} 
              products={products}
              profile={profile}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileView 
              profile={profile} 
              setProfile={setProfile}
              showNotification={showNotification}
            />
          )}
        </main>
      </div>
    </div>
  );
}

function DashboardView({ products, transactions, customers, lowStockProducts, setActiveTab }) {
  // Calculations
  const totalRevenue = transactions.reduce((acc, curr) => acc + curr.total, 0);
  const totalTransactionsCount = transactions.length;
  const totalProductsCount = products.length;

  // Best Sellers Calculation
  const topProducts = useMemo(() => {
    return [...products].sort((a, b) => b.salesCount - a.salesCount).slice(0, 4);
  }, [products]);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-purple-800 via-purple-700 to-indigo-800 rounded-3xl p-6 md:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-white/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 max-w-2xl">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-white/20 backdrop-blur-md text-purple-100 mb-3">
            <Sparkles className="w-3.5 h-3.5 text-yellow-300" /> Ringkasan Bisnis Kuliner UMKM
          </span>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Selamat Datang di Zahwa Snack System</h1>
          <p className="text-purple-200 text-xs md:text-sm mt-2 leading-relaxed">
            Kelola penjualan camilan, pantau persediaan stok renyah, dan optimalkan laporan keuangan toko Anda secara real-time dan akurat.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <button 
              onClick={() => setActiveTab('pos')} 
              className="px-5 py-2.5 bg-white text-purple-900 rounded-xl text-xs font-bold hover:bg-purple-50 transition shadow-lg shadow-purple-900/40 flex items-center gap-2"
            >
              <ShoppingCart className="w-4 h-4 text-purple-700" /> Transaksi Baru (POS)
            </button>
            <button 
              onClick={() => setActiveTab('products')} 
              className="px-5 py-2.5 bg-purple-600/50 hover:bg-purple-600 border border-purple-400/30 text-white rounded-xl text-xs font-semibold transition"
            >
              Tambah Produk Snack
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-purple-100 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Pendapatan</span>
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-purple-950 mt-3">Rp {totalRevenue.toLocaleString('id-ID')}</p>
          <p className="text-[11px] text-emerald-600 mt-1 font-medium flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> Akumulasi Seluruh Penjualan
          </p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-purple-100 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Jumlah Transaksi</span>
            <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-purple-950 mt-3">{totalTransactionsCount} Trx</p>
          <p className="text-[11px] text-slate-500 mt-1 font-medium">Selesai Diproses</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-purple-100 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Total Produk Snack</span>
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-purple-950 mt-3">{totalProductsCount} Item</p>
          <p className="text-[11px] text-slate-500 mt-1 font-medium">Tersedia di Katalog</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-purple-100 shadow-sm hover:shadow-md transition">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500">Stok Menipis</span>
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${lowStockProducts.length > 0 ? 'bg-amber-100 text-amber-700 animate-pulse' : 'bg-slate-100 text-slate-600'}`}>
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <p className="text-xl font-bold text-purple-950 mt-3">{lowStockProducts.length} Item</p>
          <p className={`text-[11px] mt-1 font-medium ${lowStockProducts.length > 0 ? 'text-amber-600' : 'text-slate-400'}`}>
            {lowStockProducts.length > 0 ? 'Perlu Restok Segera!' : 'Stok Aman Terkendali'}
          </p>
        </div>
      </div>

      {/* Grid Content: Low Stock Alerts & Best Sellers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left: Low Stock Notification Panel */}
        <div className="bg-white rounded-2xl border border-purple-100 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-purple-950 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" /> Peringatan Stok Menipis
            </h2>
            <button 
              onClick={() => setActiveTab('stock_logs')} 
              className="text-xs font-semibold text-purple-600 hover:text-purple-800"
            >
              Lihat Semua
            </button>
          </div>

          {lowStockProducts.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-2 opacity-80" />
              Semua persediaan snack dalam kondisi cukup.
            </div>
          ) : (
            <div className="space-y-3">
              {lowStockProducts.map(item => (
                <div key={item.id} className="flex items-center justify-between p-3 rounded-xl bg-amber-50/50 border border-amber-200/60">
                  <div className="flex items-center gap-3">
                    <img src={item.image} alt={item.name} className="w-10 h-10 rounded-lg object-cover" />
                    <div>
                      <p className="text-xs font-semibold text-slate-800 line-clamp-1">{item.name}</p>
                      <p className="text-[10px] text-slate-500">Min. Stok: {item.minStock} {item.unit}</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 text-xs font-bold text-red-700 bg-red-100 rounded-lg border border-red-200">
                    Sisa {item.stock}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right: Best Selling Snacks */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-purple-100 p-5 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-purple-950 flex items-center gap-2">
              <Award className="w-4 h-4 text-purple-600" /> Snack Terlaris (Top Sales)
            </h2>
            <button 
              onClick={() => setActiveTab('products')} 
              className="text-xs font-semibold text-purple-600 hover:text-purple-800"
            >
              Kelola Katalog
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {topProducts.map((prod, idx) => (
              <div key={prod.id} className="flex items-center gap-3 p-3 rounded-2xl border border-purple-100 hover:border-purple-300 transition bg-slate-50/50">
                <div className="relative">
                  <img src={prod.image} alt={prod.name} className="w-14 h-14 rounded-xl object-cover" />
                  <span className="absolute -top-2 -left-2 w-6 h-6 rounded-full bg-purple-700 text-white font-bold text-[10px] flex items-center justify-center border-2 border-white shadow">
                    #{idx + 1}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-xs font-bold text-slate-800 truncate">{prod.name}</h3>
                  <p className="text-xs font-bold text-purple-700 mt-0.5">Rp {prod.price.toLocaleString('id-ID')}</p>
                  <p className="text-[10px] text-slate-500 mt-1">
                    Terjual: <span className="font-semibold text-slate-700">{prod.salesCount} {prod.unit}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}

function POSView({ products, setProducts, customers, transactions, setTransactions, stockLogs, setStockLogs, showNotification }) {
  const [cart, setCart] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState('cust-3');
  const [discount, setDiscount] = useState(0);
  const [paidAmount, setPaidAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('Cash');
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [lastCompletedTrx, setLastCompletedTrx] = useState(null);

  // Filter products for catalog display
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchCat = selectedCategory === 'ALL' || p.categoryId === selectedCategory;
      const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.code.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSearch;
    });
  }, [products, selectedCategory, searchQuery]);

  // Add Item to Cart
  const addToCart = (product) => {
    if (product.stock <= 0) {
      showNotification(`Stok ${product.name} telah habis!`, 'error');
      return;
    }

    setCart(prevCart => {
      const existing = prevCart.find(item => item.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          showNotification(`Jumlah melebihi sisa stok ketersediaan!`, 'error');
          return prevCart;
        }
        return prevCart.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * item.price } : item
        );
      } else {
        return [...prevCart, { 
          id: product.id, 
          name: product.name, 
          price: product.price, 
          quantity: 1, 
          subtotal: product.price,
          unit: product.unit,
          maxStock: product.stock
        }];
      }
    });
  };

  // Update Cart Quantity
  const updateCartQty = (id, delta) => {
    setCart(prevCart => {
      return prevCart.map(item => {
        if (item.id === id) {
          const newQty = item.quantity + delta;
          if (newQty > item.maxStock) {
            showNotification(`Stok maksimum hanya ${item.maxStock}`, 'error');
            return item;
          }
          if (newQty <= 0) return null;
          return { ...item, quantity: newQty, subtotal: newQty * item.price };
        }
        return item;
      }).filter(Boolean);
    });
  };

  // Cart Calculations
  const subtotalCart = cart.reduce((acc, curr) => acc + curr.subtotal, 0);
  const totalPayable = Math.max(0, subtotalCart - Number(discount));
  const changeAmount = Number(paidAmount) >= totalPayable ? Number(paidAmount) - totalPayable : 0;

  // Process Transaction Finalization
  const handleCheckout = (e) => {
    e.preventDefault();

    if (cart.length === 0) {
      showNotification('Keranjang belanja masih kosong!', 'error');
      return;
    }

    if (Number(paidAmount) < totalPayable) {
      showNotification('Jumlah pembayaran kurang dari total tagihan!', 'error');
      return;
    }

    const customerObj = customers.find(c => c.id === selectedCustomerId) || { name: 'Pelanggan Umum' };
    const trxId = `TRX-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${Math.floor(1000 + Math.random() * 9000)}`;
    const trxDate = new Date().toISOString();

    const newTransaction = {
      id: trxId,
      date: trxDate,
      customerId: selectedCustomerId,
      customerName: customerObj.name,
      items: cart,
      subtotal: subtotalCart,
      discount: Number(discount),
      total: totalPayable,
      paymentMethod,
      paidAmount: Number(paidAmount),
      changeAmount,
      cashier: 'Admin Zahwa'
    };

    // 1. Deduct Stock & Increment Sales Count
    const newProducts = products.map(p => {
      const cartItem = cart.find(c => c.id === p.id);
      if (cartItem) {
        return {
          ...p,
          stock: p.stock - cartItem.quantity,
          salesCount: p.salesCount + cartItem.quantity
        };
      }
      return p;
    });

    // 2. Append Stock Reduction Logs
    const newLogs = cart.map(item => ({
      id: `log-${Date.now()}-${item.id}`,
      date: trxDate,
      productName: item.name,
      type: 'OUT',
      qty: item.quantity,
      note: `Penjualan Kasir ${trxId}`
    }));

    // Save Updates
    setProducts(newProducts);
    setTransactions([newTransaction, ...transactions]);
    setStockLogs([...newLogs, ...stockLogs]);

    // Show Printable Receipt Modal
    setLastCompletedTrx(newTransaction);
    setShowReceiptModal(true);

    // Reset Cart Form
    setCart([]);
    setDiscount(0);
    setPaidAmount('');
    showNotification('Transaksi berhasil diproses & stok otomatis berkurang!');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full items-start">
      
      {/* Left Column: Snack Catalog Picker */}
      <div className="lg:col-span-7 xl:col-span-8 space-y-4">
        
        {/* Search & Filter Header */}
        <div className="bg-white p-4 rounded-2xl border border-purple-100 shadow-sm space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari kode snack atau nama produk..." 
              className="w-full pl-10 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3 max-h-[calc(100vh-230px)] overflow-y-auto pr-1">
          {filteredProducts.map(product => {
            const isOutOfStock = product.stock <= 0;
            return (
              <div 
                key={product.id}
                onClick={() => !isOutOfStock && addToCart(product)}
                className={`bg-white rounded-2xl border transition p-3 flex flex-col justify-between cursor-pointer select-none relative group ${
                  isOutOfStock ? 'opacity-50 border-slate-200 cursor-not-allowed' : 'border-purple-100 hover:border-purple-400 hover:shadow-md'
                }`}
              >
                <div>
                  <div className="relative overflow-hidden rounded-xl mb-2.5 aspect-square bg-slate-100">
                    <img 
                      src={product.image} 
                      alt={product.name} 
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                    />
                    <span className="absolute top-1.5 left-1.5 px-2 py-0.5 rounded-md text-[9px] font-bold bg-slate-900/70 text-white backdrop-blur-sm">
                      {product.code}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 line-clamp-2 leading-snug">{product.name}</h4>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold text-purple-700">Rp {product.price.toLocaleString('id-ID')}</p>
                    <p className={`text-[10px] ${product.stock <= product.minStock ? 'text-amber-600 font-bold' : 'text-slate-400'}`}>
                      Stok: {product.stock} {product.unit}
                    </p>
                  </div>
                  <button 
                    disabled={isOutOfStock}
                    className="w-7 h-7 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center hover:bg-purple-600 hover:text-white transition"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right Column: Interactive Shopping Cart */}
      <div className="lg:col-span-5 xl:col-span-4 bg-white rounded-2xl border border-purple-100 p-5 shadow-sm space-y-4 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between border-b border-purple-100 pb-3 mb-3">
            <h3 className="font-bold text-purple-950 text-sm flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-purple-600" /> Keranjang Kasir
            </h3>
            <button 
              onClick={() => setCart([])}
              className="text-[11px] text-red-500 hover:underline font-medium"
            >
              Kosongkan
            </button>
          </div>

          {/* Selected Customer Picker */}
          <div className="mb-3">
            <label className="text-[11px] font-semibold text-slate-600 mb-1 block">Pelanggan</label>
            <select 
              value={selectedCustomerId}
              onChange={(e) => setSelectedCustomerId(e.target.value)}
              className="w-full text-xs py-2 px-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-slate-50"
            >
              {customers.map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>

          {/* Cart Item Items List */}
          <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1 my-2">
            {cart.length === 0 ? (
              <div className="text-center py-10 text-slate-400 text-xs">
                Belum ada item snack dipilih.
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="flex items-center justify-between p-2.5 rounded-xl bg-purple-50/40 border border-purple-100">
                  <div className="flex-1 min-w-0 pr-2">
                    <p className="text-xs font-bold text-slate-800 truncate">{item.name}</p>
                    <p className="text-[10px] text-purple-700">Rp {item.price.toLocaleString('id-ID')}</p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button onClick={() => updateCartQty(item.id, -1)} className="w-6 h-6 rounded-md bg-white border border-slate-200 flex items-center justify-center hover:bg-slate-100 text-slate-600">
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="text-xs font-bold text-slate-800 w-5 text-center">{item.quantity}</span>
                    <button onClick={() => updateCartQty(item.id, 1)} className="w-6 h-6 rounded-md bg-white border border-slate-200 flex items-center justify-center hover:bg-slate-100 text-slate-600">
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Payment Summary & Checkout Form */}
        <form onSubmit={handleCheckout} className="border-t border-purple-100 pt-3 space-y-3">
          <div className="space-y-1.5 text-xs text-slate-600">
            <div className="flex justify-between">
              <span>Subtotal Item</span>
              <span className="font-semibold">Rp {subtotalCart.toLocaleString('id-ID')}</span>
            </div>

            <div className="flex items-center justify-between gap-2">
              <span>Potongan Diskon (Rp)</span>
              <input 
                type="number" 
                min="0"
                value={discount} 
                onChange={(e) => setDiscount(Math.max(0, Number(e.target.value)))}
                className="w-24 text-right px-2 py-1 rounded-lg border border-slate-200 text-xs focus:ring-1 focus:ring-purple-500"
              />
            </div>

            <div className="flex justify-between text-sm font-bold text-purple-950 pt-2 border-t border-dashed border-purple-200">
              <span>Total Tagihan</span>
              <span className="text-base text-purple-700">Rp {totalPayable.toLocaleString('id-ID')}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] font-semibold text-slate-500 block mb-1">Metode Bayar</label>
              <select 
                value={paymentMethod} 
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full text-xs p-2 rounded-xl border border-slate-200 bg-slate-50"
              >
                <option value="Cash">Tunai (Cash)</option>
                <option value="QRIS">QRIS / Transfer</option>
                <option value="Debit">Kartu Debit</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] font-semibold text-slate-500 block mb-1">Uang Diterima (Rp)</label>
              <input 
                type="number" 
                required
                value={paidAmount} 
                onChange={(e) => setPaidAmount(e.target.value)}
                placeholder="0"
                className="w-full text-xs p-2 rounded-xl border border-purple-300 font-bold focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          {Number(paidAmount) >= totalPayable && totalPayable > 0 && (
            <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 flex justify-between items-center text-xs text-emerald-800">
              <span className="font-medium">Kembalian:</span>
              <span className="font-bold text-sm">Rp {changeAmount.toLocaleString('id-ID')}</span>
            </div>
          )}

          <button 
            type="submit" 
            disabled={cart.length === 0}
            className="w-full py-3 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-800 hover:to-indigo-800 text-white font-bold rounded-xl shadow-lg shadow-purple-600/30 transition duration-200 disabled:opacity-50 disabled:cursor-not-allowed text-xs uppercase tracking-wider"
          >
            Bayar & Cetak Struk
          </button>
        </form>

      </div>

      {/* Printable Receipt Modal Overlay */}
      {showReceiptModal && lastCompletedTrx && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-4 border border-purple-100">
            
            {/* Thermal Receipt Box */}
            <div id="printable-receipt" className="font-mono text-xs bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="text-center border-b border-dashed border-slate-300 pb-3">
                <h2 className="font-bold text-sm text-slate-900 uppercase">ZAHWA SNACK</h2>
                <p className="text-[10px] text-slate-500">Jl. Raya Sunan Kudus No. 88</p>
                <p className="text-[10px] text-slate-500">Telp: 0812-3456-7890</p>
              </div>

              <div className="space-y-1 text-[10px] text-slate-600">
                <p>No: {lastCompletedTrx.id}</p>
                <p>Tgl: {new Date(lastCompletedTrx.date).toLocaleString('id-ID')}</p>
                <p>Pelanggan: {lastCompletedTrx.customerName}</p>
              </div>

              <div className="border-t border-b border-dashed border-slate-300 py-2 space-y-1.5">
                {lastCompletedTrx.items.map(i => (
                  <div key={i.id} className="flex justify-between text-[11px]">
                    <div className="flex-1 pr-2">
                      <p className="font-bold text-slate-800">{i.name}</p>
                      <p className="text-[10px] text-slate-500">{i.quantity} x Rp {i.price.toLocaleString('id-ID')}</p>
                    </div>
                    <span className="font-semibold text-slate-800">Rp {i.subtotal.toLocaleString('id-ID')}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-right text-[11px]">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal:</span>
                  <span>Rp {lastCompletedTrx.subtotal.toLocaleString('id-ID')}</span>
                </div>
                {lastCompletedTrx.discount > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>Diskon:</span>
                    <span>-Rp {lastCompletedTrx.discount.toLocaleString('id-ID')}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-sm text-slate-900 border-t border-slate-200 pt-1">
                  <span>TOTAL:</span>
                  <span>Rp {lastCompletedTrx.total.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Bayar ({lastCompletedTrx.paymentMethod}):</span>
                  <span>Rp {lastCompletedTrx.paidAmount.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Kembali:</span>
                  <span>Rp {lastCompletedTrx.changeAmount.toLocaleString('id-ID')}</span>
                </div>
              </div>

              <div className="text-center pt-2 border-t border-dashed border-slate-300 text-[9px] text-slate-400">
                <p>Terima Kasih Atas Kunjungan Anda!</p>
                <p>Camilan Renyah Gurih Nikmat Setiap Hari</p>
              </div>
            </div>

            {/* Modal Action Buttons */}
            <div className="flex gap-2">
              <button 
                onClick={() => window.print()}
                className="flex-1 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2"
              >
                <Printer className="w-4 h-4" /> Cetak Struk
              </button>
              <button 
                onClick={() => setShowReceiptModal(false)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
              >
                Tutup
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}

function ProductsView({ products, setProducts, categories, showNotification, setConfirmModal }) {
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('ALL');

  // Form Initial State
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    categoryId: categories[0]?.id || '',
    price: '',
    costPrice: '',
    stock: '',
    minStock: 5,
    unit: 'Bungkus',
    image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=400&auto=format&fit=crop&q=80'
  });

  const openAddModal = () => {
    setEditingProduct(null);
    setFormData({
      code: `ZS-${Math.floor(100 + Math.random() * 900)}`,
      name: '',
      categoryId: categories[0]?.id || '',
      price: '',
      costPrice: '',
      stock: '',
      minStock: 5,
      unit: 'Bungkus',
      image: 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=400&auto=format&fit=crop&q=80'
    });
    setShowModal(true);
  };

  const openEditModal = (prod) => {
    setEditingProduct(prod);
    setFormData({ ...prod });
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (Number(formData.price) <= 0 || Number(formData.stock) < 0) {
      showNotification('Harga dan stok harus valid (tidak boleh negatif)!', 'error');
      return;
    }

    if (editingProduct) {
      setProducts(products.map(p => p.id === editingProduct.id ? { 
        ...formData, 
        price: Number(formData.price), 
        costPrice: Number(formData.costPrice),
        stock: Number(formData.stock),
        minStock: Number(formData.minStock)
      } : p));
      showNotification('Produk berhasil diperbarui!');
    } else {
      const newProd = {
        ...formData,
        id: `prd-${Date.now()}`,
        price: Number(formData.price),
        costPrice: Number(formData.costPrice),
        stock: Number(formData.stock),
        minStock: Number(formData.minStock),
        salesCount: 0
      };
      setProducts([newProd, ...products]);
      showNotification('Produk snack baru berhasil ditambahkan!');
    }
    setShowModal(false);
  };

  const handleDelete = (id, name) => {
    setConfirmModal({
      isOpen: true,
      title: 'Hapus Produk Snack?',
      message: `Apakah Anda yakin ingin menghapus "${name}" dari katalog?`,
      onConfirm: () => {
        setProducts(products.filter(p => p.id !== id));
        showNotification(`Produk ${name} berhasil dihapus`, 'info');
      }
    });
  };

  const filteredProducts = products.filter(p => {
    const matchCat = filterCategory === 'ALL' || p.categoryId === filterCategory;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.code.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="space-y-4">
      {/* Header Actions & Filter */}
      <div className="bg-white p-4 rounded-2xl border border-purple-100 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto flex-1">
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari kode atau produk..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none"
            />
          </div>

          <select 
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="w-full sm:w-48 text-xs py-2 px-3 rounded-xl border border-slate-200 bg-slate-50 focus:outline-none"
          >
            <option value="ALL">Semua Kategori</option>
            {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>

        <button 
          onClick={openAddModal}
          className="w-full sm:w-auto px-4 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 shadow-md shadow-purple-600/20 transition"
        >
          <Plus className="w-4 h-4" /> Tambah Produk Snack
        </button>
      </div>

      {/* Table Data */}
      <div className="bg-white rounded-2xl border border-purple-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-purple-50/60 border-b border-purple-100 text-[11px] font-bold text-purple-950 uppercase">
                <th className="p-4">Produk</th>
                <th className="p-4">Kode</th>
                <th className="p-4">Kategori</th>
                <th className="p-4">Harga Jual</th>
                <th className="p-4">Harga Modal</th>
                <th className="p-4">Stok</th>
                <th className="p-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredProducts.map(prod => {
                const categoryName = categories.find(c => c.id === prod.categoryId)?.name || 'Umum';
                const isLowStock = prod.stock <= prod.minStock;
                return (
                  <tr key={prod.id} className="hover:bg-purple-50/30 transition">
                    <td className="p-4 flex items-center gap-3">
                      <img src={prod.image} alt={prod.name} className="w-10 h-10 rounded-xl object-cover border border-slate-200" />
                      <div>
                        <p className="font-bold text-slate-800">{prod.name}</p>
                        <p className="text-[10px] text-slate-400">{prod.unit}</p>
                      </div>
                    </td>
                    <td className="p-4 font-mono font-medium text-slate-600">{prod.code}</td>
                    <td className="p-4">
                      <span className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-purple-100 text-purple-800">
                        {categoryName}
                      </span>
                    </td>
                    <td className="p-4 font-bold text-purple-700">Rp {prod.price.toLocaleString('id-ID')}</td>
                    <td className="p-4 text-slate-500">Rp {prod.costPrice.toLocaleString('id-ID')}</td>
                    <td className="p-4">
                      <span className={`px-2 py-1 rounded-md text-[10px] font-bold ${
                        isLowStock ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {prod.stock} {prod.unit} {isLowStock && '⚠️'}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-2">
                        <button 
                          onClick={() => openEditModal(prod)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition" 
                          title="Edit Produk"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleDelete(prod.id, prod.name)}
                          className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition" 
                          title="Hapus Produk"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* CRUD Product Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-purple-100 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-purple-100 pb-3">
              <h3 className="font-bold text-purple-950 text-base">
                {editingProduct ? 'Edit Data Produk Snack' : 'Tambah Produk Snack Baru'}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Kode SKU</label>
                  <input 
                    type="text" 
                    required 
                    value={formData.code} 
                    onChange={e => setFormData({ ...formData, code: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Kategori</label>
                  <select 
                    value={formData.categoryId} 
                    onChange={e => setFormData({ ...formData, categoryId: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white"
                  >
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nama Produk Snack</label>
                <input 
                  type="text" 
                  required 
                  value={formData.name} 
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: Keripik Balado Pedas"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Harga Jual (Rp)</label>
                  <input 
                    type="number" 
                    required 
                    min="1"
                    value={formData.price} 
                    onChange={e => setFormData({ ...formData, price: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Harga Modal (Rp)</label>
                  <input 
                    type="number" 
                    required 
                    min="0"
                    value={formData.costPrice} 
                    onChange={e => setFormData({ ...formData, costPrice: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Stok Awal</label>
                  <input 
                    type="number" 
                    required 
                    min="0"
                    value={formData.stock} 
                    onChange={e => setFormData({ ...formData, stock: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Min. Stok Warning</label>
                  <input 
                    type="number" 
                    required 
                    min="1"
                    value={formData.minStock} 
                    onChange={e => setFormData({ ...formData, minStock: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 block mb-1">Satuan Kemasan</label>
                  <select 
                    value={formData.unit} 
                    onChange={e => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none bg-white"
                  >
                    <option value="Bungkus">Bungkus</option>
                    <option value="Pouch">Pouch</option>
                    <option value="Toples">Toples</option>
                    <option value="Kg">Kg</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">URL Gambar Produk</label>
                <input 
                  type="url" 
                  value={formData.image} 
                  onChange={e => setFormData({ ...formData, image: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                />
              </div>

              <div className="pt-3 flex gap-2">
                <button 
                  type="submit" 
                  className="flex-1 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold shadow-md transition"
                >
                  {editingProduct ? 'Simpan Perubahan' : 'Tambah Produk'}
                </button>
                <button 
                  type="button" 
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-xs font-semibold"
                >
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

function CategoriesView({ categories, setCategories, products, showNotification, setConfirmModal }) {
  const [showModal, setShowModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [formData, setFormData] = useState({ name: '', description: '' });

  const openAddModal = () => {
    setEditingCategory(null);
    setFormData({ name: '', description: '' });
    setShowModal(true);
  };

  const openEditModal = (cat) => {
    setEditingCategory(cat);
    setFormData({ name: cat.name, description: cat.description });
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingCategory) {
      setCategories(categories.map(c => c.id === editingCategory.id ? { ...c, ...formData } : c));
      showNotification('Kategori berhasil diperbarui!');
    } else {
      const newCat = { id: `cat-${Date.now()}`, ...formData };
      setCategories([...categories, newCat]);
      showNotification('Kategori baru berhasil ditambahkan!');
    }
    setShowModal(false);
  };

  const handleDelete = (id, name) => {
    const isUsed = products.some(p => p.categoryId === id);
    if (isUsed) {
      showNotification(`Tidak dapat menghapus kategori "${name}" karena sedang digunakan oleh produk!`, 'error');
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Hapus Kategori?',
      message: `Apakah Anda yakin menghapus kategori "${name}"?`,
      onConfirm: () => {
        setCategories(categories.filter(c => c.id !== id));
        showNotification('Kategori berhasil dihapus', 'info');
      }
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-purple-100 shadow-sm">
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Daftar Kategori Produk</h3>
          <p className="text-xs text-slate-500">Kelompokkan snack berdasarkan jenis kuliner</p>
        </div>
        <button 
          onClick={openAddModal}
          className="px-4 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-md"
        >
          <Plus className="w-4 h-4" /> Tambah Kategori
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map(cat => {
          const productCount = products.filter(p => p.categoryId === cat.id).length;
          return (
            <div key={cat.id} className="bg-white rounded-2xl p-5 border border-purple-100 shadow-sm flex flex-col justify-between space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="p-2 rounded-xl bg-purple-100 text-purple-700">
                    <FolderTree className="w-5 h-5" />
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                    {productCount} Produk
                  </span>
                </div>
                <h4 className="font-bold text-slate-800 text-sm">{cat.name}</h4>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2">{cat.description || 'Tidak ada deskripsi'}</p>
              </div>

              <div className="flex justify-end gap-2 border-t border-purple-50 pt-3">
                <button onClick={() => openEditModal(cat)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg">
                  <Edit className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(cat.id, cat.name)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-purple-100 space-y-4">
            <div className="flex justify-between items-center border-b border-purple-100 pb-3">
              <h3 className="font-bold text-purple-950 text-base">
                {editingCategory ? 'Edit Kategori' : 'Tambah Kategori Baru'}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nama Kategori</label>
                <input 
                  type="text" 
                  required 
                  value={formData.name} 
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: Kue Kering"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none" 
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Deskripsi Ringkas</label>
                <textarea 
                  value={formData.description} 
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Penjelasan singkat kategori produk..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 focus:outline-none h-20 resize-none" 
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button type="submit" className="flex-1 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold shadow-md">
                  {editingCategory ? 'Simpan Perubahan' : 'Tambah Kategori'}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-xs font-semibold">
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function StockLogsView({ products, setProducts, stockLogs, setStockLogs, showNotification }) {
  const [selectedProductId, setSelectedProductId] = useState(products[0]?.id || '');
  const [adjustType, setAdjustType] = useState('IN');
  const [adjustQty, setAdjustQty] = useState('');
  const [adjustNote, setAdjustNote] = useState('');

  const handleStockAdjust = (e) => {
    e.preventDefault();
    const qtyNum = Number(adjustQty);

    if (qtyNum <= 0) {
      showNotification('Jumlah stok harus lebih besar dari 0!', 'error');
      return;
    }

    const targetProd = products.find(p => p.id === selectedProductId);
    if (!targetProd) return;

    if (adjustType === 'OUT' && targetProd.stock < qtyNum) {
      showNotification(`Gagal! Pengurangan melebihi stok yang ada (${targetProd.stock})`, 'error');
      return;
    }

    // Calculate New Stock
    const newStock = adjustType === 'IN' ? targetProd.stock + qtyNum : targetProd.stock - qtyNum;

    setProducts(products.map(p => p.id === selectedProductId ? { ...p, stock: newStock } : p));

    const newLog = {
      id: `log-${Date.now()}`,
      date: new Date().toISOString(),
      productName: targetProd.name,
      type: adjustType,
      qty: qtyNum,
      note: adjustNote || (adjustType === 'IN' ? 'Restok Manual' : 'Koreksi Stok Terbuang/Rusak')
    };

    setStockLogs([newLog, ...stockLogs]);
    setAdjustQty('');
    setAdjustNote('');
    showNotification(`Penyesuaian stok ${targetProd.name} berhasil disukai!`);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Stock Adjustment Form */}
      <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-purple-100 shadow-sm space-y-4">
        <h3 className="font-bold text-purple-950 text-sm flex items-center gap-2 border-b border-purple-100 pb-3">
          <RefreshCw className="w-4 h-4 text-purple-600" /> Penyesuaian Stok Manual (Restok)
        </h3>

        <form onSubmit={handleStockAdjust} className="space-y-3">
          <div>
            <label className="text-[11px] font-semibold text-slate-700 block mb-1">Pilih Produk Snack</label>
            <select 
              value={selectedProductId}
              onChange={e => setSelectedProductId(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 bg-slate-50"
            >
              {products.map(p => (
                <option key={p.id} value={p.id}>
                  {p.name} (Sisa: {p.stock} {p.unit})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Jenis Log</label>
              <select 
                value={adjustType}
                onChange={e => setAdjustType(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50 font-bold"
              >
                <option value="IN">Stok Masuk (+)</option>
                <option value="OUT">Stok Keluar (-)</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">Jumlah Item</label>
              <input 
                type="number" 
                required 
                min="1"
                value={adjustQty}
                onChange={e => setAdjustQty(e.target.value)}
                placeholder="0"
                className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-semibold text-slate-700 block mb-1">Keterangan / Catatan Restok</label>
            <input 
              type="text" 
              value={adjustNote}
              onChange={e => setAdjustNote(e.target.value)}
              placeholder="Contoh: Kiriman dari Suplier Pabrik"
              className="w-full text-xs p-2.5 rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <button 
            type="submit" 
            className="w-full py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold shadow-md transition"
          >
            Update Mutasi Stok
          </button>
        </form>
      </div>

      {/* Audit Log Table */}
      <div className="lg:col-span-7 bg-white rounded-2xl border border-purple-100 p-5 shadow-sm space-y-3">
        <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
          <Bell className="w-4 h-4 text-purple-600" /> Riwayat Mutasi Stok Realtime
        </h3>

        <div className="overflow-x-auto max-h-[420px]">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-purple-50/60 border-b border-purple-100 text-[10px] font-bold text-purple-900 uppercase">
                <th className="p-2.5">Waktu</th>
                <th className="p-2.5">Produk</th>
                <th className="p-2.5">Tipe</th>
                <th className="p-2.5">Qty</th>
                <th className="p-2.5">Keterangan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {stockLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="p-2.5 text-[10px] text-slate-500 font-mono">
                    {new Date(log.date).toLocaleString('id-ID')}
                  </td>
                  <td className="p-2.5 font-bold text-slate-800">{log.productName}</td>
                  <td className="p-2.5">
                    <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                      log.type === 'IN' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {log.type === 'IN' ? 'MASUK' : 'KELUAR'}
                    </span>
                  </td>
                  <td className="p-2.5 font-bold">{log.qty}</td>
                  <td className="p-2.5 text-slate-500 text-[11px]">{log.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

function CustomersView({ customers, setCustomers, showNotification, setConfirmModal }) {
  const [showModal, setShowModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [formData, setFormData] = useState({ name: '', phone: '', address: '' });

  const openAddModal = () => {
    setEditingCustomer(null);
    setFormData({ name: '', phone: '', address: '' });
    setShowModal(true);
  };

  const openEditModal = (cust) => {
    setEditingCustomer(cust);
    setFormData({ name: cust.name, phone: cust.phone, address: cust.address });
    setShowModal(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingCustomer) {
      setCustomers(customers.map(c => c.id === editingCustomer.id ? { ...c, ...formData } : c));
      showNotification('Data pelanggan diperbarui!');
    } else {
      const newCust = {
        id: `cust-${Date.now()}`,
        ...formData,
        totalOrders: 0,
        totalSpent: 0
      };
      setCustomers([...customers, newCust]);
      showNotification('Pelanggan baru berhasil ditambahkan!');
    }
    setShowModal(false);
  };

  const handleDelete = (id, name) => {
    setConfirmModal({
      isOpen: true,
      title: 'Hapus Pelanggan?',
      message: `Hapus pelanggan "${name}" dari database?`,
      onConfirm: () => {
        setCustomers(customers.filter(c => c.id !== id));
        showNotification('Pelanggan berhasil dihapus', 'info');
      }
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-purple-100 shadow-sm">
        <div>
          <h3 className="font-bold text-slate-800 text-sm">Database Pelanggan Snack</h3>
          <p className="text-xs text-slate-500">Kelola riwayat kontak dan loyalitas pembeli</p>
        </div>
        <button 
          onClick={openAddModal}
          className="px-4 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-md"
        >
          <Plus className="w-4 h-4" /> Tambah Pelanggan
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-purple-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-purple-50/60 border-b border-purple-100 text-[10px] font-bold text-purple-950 uppercase">
                <th className="p-4">Nama Pelanggan</th>
                <th className="p-4">No. WhatsApp / HP</th>
                <th className="p-4">Alamat</th>
                <th className="p-4">Total Pembelian</th>
                <th className="p-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {customers.map(cust => (
                <tr key={cust.id} className="hover:bg-purple-50/30 transition">
                  <td className="p-4 font-bold text-slate-800 flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-[10px]">
                      {cust.name.substring(0,2).toUpperCase()}
                    </div>
                    {cust.name}
                  </td>
                  <td className="p-4 text-slate-600 font-mono">{cust.phone}</td>
                  <td className="p-4 text-slate-500 max-w-xs truncate">{cust.address}</td>
                  <td className="p-4 font-bold text-purple-700">Rp {cust.totalSpent.toLocaleString('id-ID')}</td>
                  <td className="p-4 text-center">
                    <div className="flex justify-center gap-2">
                      <button onClick={() => openEditModal(cust)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(cust.id, cust.name)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-purple-100 space-y-4">
            <div className="flex justify-between items-center border-b border-purple-100 pb-3">
              <h3 className="font-bold text-purple-950 text-base">
                {editingCustomer ? 'Edit Pelanggan' : 'Tambah Pelanggan Baru'}
              </h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Nama Lengkap</label>
                <input 
                  type="text" 
                  required 
                  value={formData.name} 
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Contoh: Budi Santoso"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500" 
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">No. WhatsApp / HP</label>
                <input 
                  type="text" 
                  required 
                  value={formData.phone} 
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="08123456789"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500" 
                />
              </div>

              <div>
                <label className="text-[11px] font-semibold text-slate-700 block mb-1">Alamat Lengkap</label>
                <textarea 
                  value={formData.address} 
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Alamat pengiriman / rumah..."
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 h-20 resize-none" 
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button type="submit" className="flex-1 py-2.5 bg-purple-700 text-white rounded-xl text-xs font-semibold shadow-md">
                  {editingCustomer ? 'Simpan' : 'Tambah Pelanggan'}
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="px-4 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-xs font-semibold">
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function TransactionsView({ transactions, profile }) {
  const [selectedTrx, setSelectedTrx] = useState(null);
  const [filterDate, setFilterDate] = useState('');

  const filteredTrx = useMemo(() => {
    if (!filterDate) return transactions;
    return transactions.filter(t => t.date.startsWith(filterDate));
  }, [transactions, filterDate]);

  return (
    <div className="space-y-4">
      {/* Date Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-purple-100 shadow-sm flex flex-col sm:flex-row justify-between items-center gap-3">
        <h3 className="font-bold text-slate-800 text-sm">Riwayat Penjualan Snack</h3>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <input 
            type="date" 
            value={filterDate}
            onChange={e => setFilterDate(e.target.value)}
            className="text-xs px-3 py-2 rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
          />
          {filterDate && (
            <button 
              onClick={() => setFilterDate('')}
              className="text-xs text-red-500 hover:underline"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-white rounded-2xl border border-purple-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-purple-50/60 border-b border-purple-100 text-[10px] font-bold text-purple-950 uppercase">
                <th className="p-4">ID Transaksi</th>
                <th className="p-4">Tanggal & Waktu</th>
                <th className="p-4">Pelanggan</th>
                <th className="p-4">Metode Bayar</th>
                <th className="p-4">Total</th>
                <th className="p-4 text-center">Detail</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredTrx.map(trx => (
                <tr key={trx.id} className="hover:bg-purple-50/30 transition">
                  <td className="p-4 font-mono font-bold text-purple-800">{trx.id}</td>
                  <td className="p-4 text-slate-500">{new Date(trx.date).toLocaleString('id-ID')}</td>
                  <td className="p-4 font-semibold text-slate-800">{trx.customerName}</td>
                  <td className="p-4">
                    <span className="px-2 py-1 rounded-md text-[10px] font-bold bg-purple-100 text-purple-800">
                      {trx.paymentMethod}
                    </span>
                  </td>
                  <td className="p-4 font-bold text-purple-900">Rp {trx.total.toLocaleString('id-ID')}</td>
                  <td className="p-4 text-center">
                    <button 
                      onClick={() => setSelectedTrx(trx)}
                      className="p-1.5 text-purple-600 hover:bg-purple-50 rounded-lg transition"
                      title="Lihat Detail Rincian"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal Overlay */}
      {selectedTrx && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-purple-100 space-y-4">
            <div className="flex justify-between items-center border-b border-purple-100 pb-3">
              <div>
                <h3 className="font-bold text-purple-950 text-sm">Rincian Nota Transaksi</h3>
                <p className="text-[10px] text-slate-500">{selectedTrx.id}</p>
              </div>
              <button onClick={() => setSelectedTrx(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="bg-purple-50/50 p-3 rounded-xl space-y-1">
                <p className="flex justify-between">
                  <span className="text-slate-500">Tanggal:</span>
                  <span className="font-semibold">{new Date(selectedTrx.date).toLocaleString('id-ID')}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-slate-500">Pelanggan:</span>
                  <span className="font-semibold">{selectedTrx.customerName}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-slate-500">Kasir:</span>
                  <span className="font-semibold">{selectedTrx.cashier}</span>
                </p>
              </div>

              <div className="border border-slate-100 rounded-xl p-3 space-y-2">
                <p className="font-bold text-[11px] text-slate-800 border-b border-slate-100 pb-1">Daftar Item Snack:</p>
                {selectedTrx.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-xs">
                    <div>
                      <p className="font-semibold text-slate-800">{item.name}</p>
                      <p className="text-[10px] text-slate-400">{item.quantity} x Rp {item.price.toLocaleString('id-ID')}</p>
                    </div>
                    <span className="font-bold text-slate-700">Rp {item.subtotal.toLocaleString('id-ID')}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-1 text-right pt-2 border-t border-slate-100">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal:</span>
                  <span>Rp {selectedTrx.subtotal.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Diskon:</span>
                  <span>-Rp {selectedTrx.discount.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-purple-950 pt-1 border-t border-slate-200">
                  <span>TOTAL AKHIR:</span>
                  <span className="text-purple-700">Rp {selectedTrx.total.toLocaleString('id-ID')}</span>
                </div>
              </div>
            </div>

            <button 
              onClick={() => setSelectedTrx(null)}
              className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
            >
              Tutup
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ReportsView({ transactions, products, profile }) {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  // Filtered transactions by custom date range
  const filteredReports = useMemo(() => {
    return transactions.filter(t => {
      const trxDate = t.date.slice(0, 10);
      if (startDate && trxDate < startDate) return false;
      if (endDate && trxDate > endDate) return false;
      return true;
    });
  }, [transactions, startDate, endDate]);

  const totalOmset = filteredReports.reduce((acc, curr) => acc + curr.total, 0);
  
  // Calculate Profit
  const totalLaba = useMemo(() => {
    let profit = 0;
    filteredReports.forEach(t => {
      t.items.forEach(item => {
        const productObj = products.find(p => p.id === item.id);
        const costPrice = productObj ? productObj.costPrice : item.price * 0.7;
        profit += (item.price - costPrice) * item.quantity;
      });
    });
    return Math.max(0, profit);
  }, [filteredReports, products]);

  // Export Report to CSV Format
  const exportCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "ID Transaksi,Tanggal,Pelanggan,Metode,Total\n";

    filteredReports.forEach(row => {
      csvContent += `${row.id},${row.date},${row.customerName},${row.paymentMethod},${row.total}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Laporan_Zahwa_Snack_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Date Filter & Export Header */}
      <div className="bg-white p-4 rounded-2xl border border-purple-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div>
            <label className="text-[10px] font-semibold text-slate-500 block">Dari Tanggal</label>
            <input 
              type="date" 
              value={startDate} 
              onChange={e => setStartDate(e.target.value)}
              className="text-xs px-3 py-1.5 rounded-xl border border-slate-200"
            />
          </div>
          <div>
            <label className="text-[10px] font-semibold text-slate-500 block">Sampai Tanggal</label>
            <input 
              type="date" 
              value={endDate} 
              onChange={e => setEndDate(e.target.value)}
              className="text-xs px-3 py-1.5 rounded-xl border border-slate-200"
            />
          </div>
          {(startDate || endDate) && (
            <button 
              onClick={() => { setStartDate(''); setEndDate(''); }}
              className="text-xs text-red-500 hover:underline mt-4"
            >
              Reset
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <button 
            onClick={exportCSV}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-md"
          >
            <Download className="w-4 h-4" /> Ekspor CSV
          </button>
          <button 
            onClick={() => window.print()}
            className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-md"
          >
            <Printer className="w-4 h-4" /> Cetak Laporan
          </button>
        </div>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-purple-100 shadow-sm">
          <p className="text-xs font-semibold text-slate-500">Total Omset (Kotor)</p>
          <p className="text-xl font-bold text-purple-950 mt-2">Rp {totalOmset.toLocaleString('id-ID')}</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-purple-100 shadow-sm">
          <p className="text-xs font-semibold text-slate-500">Estimasi Keuntungan Bersih</p>
          <p className="text-xl font-bold text-emerald-600 mt-2">Rp {totalLaba.toLocaleString('id-ID')}</p>
        </div>
        <div className="bg-white p-5 rounded-2xl border border-purple-100 shadow-sm">
          <p className="text-xs font-semibold text-slate-500">Transaksi Berhasil</p>
          <p className="text-xl font-bold text-indigo-700 mt-2">{filteredReports.length} Transaksi</p>
        </div>
      </div>

      {/* Printable Report Content */}
      <div className="bg-white rounded-2xl border border-purple-100 shadow-sm p-6 space-y-4">
        <div className="text-center border-b border-purple-100 pb-4">
          <h2 className="text-lg font-bold text-purple-950 uppercase">{profile.name}</h2>
          <p className="text-xs text-slate-500">Laporan Penjualan & Margin Keuntungan UMKM</p>
          <p className="text-[10px] text-slate-400 mt-1">Dicetak pada: {new Date().toLocaleString('id-ID')}</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-purple-50/80 border-b border-purple-100 text-[10px] font-bold text-purple-950 uppercase">
                <th className="p-3">Tanggal</th>
                <th className="p-3">No. Trx</th>
                <th className="p-3">Pelanggan</th>
                <th className="p-3">Rincian Item</th>
                <th className="p-3 text-right">Total Transaksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredReports.map(trx => (
                <tr key={trx.id}>
                  <td className="p-3 text-slate-500">{new Date(trx.date).toLocaleDateString('id-ID')}</td>
                  <td className="p-3 font-mono font-bold text-purple-800">{trx.id}</td>
                  <td className="p-3 font-semibold text-slate-800">{trx.customerName}</td>
                  <td className="p-3 text-slate-600">
                    {trx.items.map(i => `${i.name} (${i.quantity})`).join(', ')}
                  </td>
                  <td className="p-3 text-right font-bold text-purple-900">Rp {trx.total.toLocaleString('id-ID')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

function ProfileView({ profile, setProfile, showNotification }) {
  const [formData, setFormData] = useState({ ...profile });

  const handleSubmit = (e) => {
    e.preventDefault();
    setProfile(formData);
    showNotification('Profil identitas usaha berhasil diperbarui!');
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-3xl border border-purple-100 shadow-sm p-6 md:p-8 space-y-6">
      <div className="flex items-center gap-4 border-b border-purple-100 pb-5">
        <div className="w-16 h-16 rounded-2xl bg-purple-700 text-white flex items-center justify-center font-bold text-xl shadow-lg shadow-purple-600/30">
          ZS
        </div>
        <div>
          <h2 className="text-lg font-bold text-purple-950">{profile.name}</h2>
          <p className="text-xs text-slate-500">{profile.tagline}</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Nama Usaha UMKM</label>
            <input 
              type="text" 
              required
              value={formData.name} 
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Slogan / Tagline</label>
            <input 
              type="text" 
              value={formData.tagline} 
              onChange={e => setFormData({ ...formData, tagline: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Pemilik Usaha</label>
            <input 
              type="text" 
              value={formData.owner} 
              onChange={e => setFormData({ ...formData, owner: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">No. Kontak / WhatsApp</label>
            <input 
              type="text" 
              value={formData.phone} 
              onChange={e => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1">Email Kontak</label>
            <input 
              type="email" 
              value={formData.email} 
              onChange={e => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">Alamat Outlet / Toko</label>
          <input 
            type="text" 
            value={formData.address} 
            onChange={e => setFormData({ ...formData, address: e.target.value })}
            className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500"
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-700 block mb-1">Deskripsi Usaha</label>
          <textarea 
            value={formData.description} 
            onChange={e => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-200 focus:ring-2 focus:ring-purple-500 h-24 resize-none"
          />
        </div>

        <button 
          type="submit" 
          className="px-6 py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-semibold shadow-md transition"
        >
          Simpan Profil Usaha
        </button>
      </form>
    </div>
  );
}