@echo off
cd /d "%~dp0"
echo =============================================
echo Zahwa Snack Management System
echo =============================================
where npm >nul 2>nul
if errorlevel 1 (
  echo Node.js dan npm belum ditemukan. Instal Node.js LTS dari https://nodejs.org lalu buka ulang terminal.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Menginstal dependensi pertama kali...
  call npm install
  if errorlevel 1 (
    echo Instalasi gagal. Periksa koneksi internet dan coba lagi.
    pause
    exit /b 1
  )
)
call npm run dev -- --host 127.0.0.1
pause
