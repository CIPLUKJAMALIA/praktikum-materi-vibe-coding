@echo off
cd /d "%~dp0"
where npm >nul 2>nul
if errorlevel 1 (
  echo Node.js dan npm belum ditemukan. Instal Node.js LTS terlebih dahulu.
  pause
  exit /b 1
)
if not exist node_modules call npm install
if errorlevel 1 goto failed
call npm run build
if errorlevel 1 goto failed
echo.
echo Build selesai. Salin ISI folder dist ke C:\laragon\www\zahwa-snack\
echo Lalu jalankan Laragon dan buka http://localhost/zahwa-snack/
pause
exit /b 0
:failed
echo Build gagal. Baca pesan error di atas.
pause
exit /b 1
