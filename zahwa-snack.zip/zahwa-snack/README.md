# Zahwa Snack Management System

Proyek React hasil penataan kode Gemini agar dapat dibuka di Visual Studio Code.

## Isi folder
- `src/App.jsx` — aplikasi utama Zahwa Snack dari kode yang diberikan.
- `src/main.jsx` — titik masuk React.
- `src/style.css` — aturan dasar dan cetak struk.
- `index.html` — halaman awal, memuat Tailwind Play CDN.
- `package.json` — dependensi dan perintah proyek.
- `vite.config.js` — konfigurasi Vite.
- `start.bat` — instal dependensi (jika perlu) lalu jalankan mode pengembangan.
- `build-for-laragon.bat` — build aplikasi untuk disalin ke folder web Laragon.

## Prasyarat
Instal Node.js versi LTS dari https://nodejs.org. Setelah instalasi, tutup lalu buka lagi VS Code.

## Cara menjalankan di VS Code
1. Ekstrak ZIP.
2. VS Code → File → Open Folder → pilih folder `zahwa-snack-vscode`.
3. Buka Terminal → New Terminal.
4. Jalankan `npm install` (cukup sekali).
5. Jalankan `npm run dev`.
6. Buka alamat lokal yang muncul di terminal, biasanya `http://localhost:5173`.

Alternatif Windows: klik dua kali `start.bat`.

## Cara menjalankan hasil build melalui Laragon
1. Pastikan `npm install` sudah selesai.
2. Jalankan `npm run build` atau klik `build-for-laragon.bat`.
3. Salin SELURUH ISI folder `dist` ke folder baru `C:\laragon\www\zahwa-snack\`.
4. Jalankan Start All di Laragon.
5. Buka `http://localhost/zahwa-snack/`.

Catatan: Laragon hanya menyajikan hasil build statis pada langkah ini. Aplikasi yang ada di ZIP menggunakan React dan localStorage, belum menggunakan PHP/MySQL. Data demo disimpan di browser yang sama. Tailwind CSS dimuat melalui CDN, jadi koneksi internet diperlukan untuk styling Tailwind. Gambar produk demo juga menggunakan URL gambar eksternal.

## Login demo
Pada halaman login, akun demo biasanya sudah terisi pada formulir. Jika formulir menampilkan kredensial demo, gunakan nilai tersebut. Login ini hanya simulasi frontend, bukan autentikasi aman untuk penggunaan produksi.
